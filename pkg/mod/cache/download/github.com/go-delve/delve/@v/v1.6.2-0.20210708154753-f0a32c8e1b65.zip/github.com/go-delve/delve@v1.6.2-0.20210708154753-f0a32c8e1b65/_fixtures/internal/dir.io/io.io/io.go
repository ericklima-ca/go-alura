package ioio

type SomeOtherType struct {
	Y int
}
